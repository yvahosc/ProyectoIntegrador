package org.makaia.transactionBankingSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionBankingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionBankingSystemApplication.class, args);
	}

}
