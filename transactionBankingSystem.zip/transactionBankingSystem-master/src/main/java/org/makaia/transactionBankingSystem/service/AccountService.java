package org.makaia.transactionBankingSystem.service;

import org.makaia.transactionBankingSystem.dto.dtoAccount.DTOAccountCreation;
import org.makaia.transactionBankingSystem.dto.dtoAccount.DTOAccountDeposit;
import org.makaia.transactionBankingSystem.dto.dtoAccount.DTOAccountTransfer;
import org.makaia.transactionBankingSystem.dto.dtoPerson.DTOPersonCreate;
import org.makaia.transactionBankingSystem.dto.dtoPocket.DTOPocketConsultIn;
import org.makaia.transactionBankingSystem.dto.dtoPocket.DTOPocketConsultOut;
import org.makaia.transactionBankingSystem.exception.ApiException;
import org.makaia.transactionBankingSystem.model.Account;
import org.makaia.transactionBankingSystem.model.Person;
import org.makaia.transactionBankingSystem.repository.AccountRepository;
import org.makaia.transactionBankingSystem.validation.AccountValidation;
import org.makaia.transactionBankingSystem.validation.PersonValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
public class AccountService {
    AccountRepository accountRepository;
    AccountValidation accountValidation;
    PersonValidation personValidation;
    PersonService personService;
    PocketService pocketService;

    @Autowired
    public AccountService(AccountRepository accountRepository, AccountValidation accountValidation, PersonValidation personValidation,
                          PersonService personService, PocketService pocketService)
    {
        this.accountRepository = accountRepository;
        this.accountValidation = accountValidation;
        this.personValidation = personValidation;
        this.personService = personService;
        this.pocketService = pocketService;
    }

    public Account getAccountById(Long id/*, HttpServletRequest request*/)
    throws ApiException {
        /*
        getAccountValidation.setId(id);
        String message = getAccountValidation.validationEntryData();
        if(!message.isEmpty()){
            List<String> error = List.of(message);
            throw new ApiException (400, error);
        }
         */

        accountValidation.getAccountValidation(id);
        //isLoggedInUserTheOwnerOfTheAccount(id, request.getUserPrincipal()
        // .getName());
        Optional<Account> account = this.accountRepository.findById(id);
        if (account.isEmpty()){
            List<String> error = List.of("La cuenta con id '" + id + "' no se encuentra en la base de datos.");
            throw new ApiException (400, error);
        }
        return account.get();
    }


    public Account createAccount(DTOAccountCreation dtoAccountCreation) throws ApiException {
        /*
        createAccountValidation.setDtoAccountCreation(dtoAccountCreation);
        String message = createAccountValidation.validationEntryData();

        if(!message.isEmpty()){
            List<String> error = List.of(message);
            throw new ApiException (400, error);
        }
         */
        accountValidation.createAccountValidation(dtoAccountCreation);

        /*
        createPersonValidation.setPerson(dtoAccountCreation.getOwner());
        String message2 =  createPersonValidation.validationEntryData();

        if(!message2.isEmpty()){
            List<String> error2 = List.of(message2);

            throw new ApiException (400, error2);
        }
         */
        personValidation.createPersonValidation(dtoAccountCreation.getOwner().getPerson());

        Person existingPerson = getPersonById(dtoAccountCreation.getOwner().getPerson().getId());
        if(existingPerson != null){
            Account account = new Account(Math.round(100000000000000L + Math.random() * 999999999999999L),
                    dtoAccountCreation.getInitialBalance(), dtoAccountCreation.getOwner().getPerson());
            return this.accountRepository.save(account);
        }else{
            Person createdPerson = createPerson(dtoAccountCreation.getOwner());
            Account account = new Account(Math.round(100000000000000L + Math.random() * 999999999999999L),
                    dtoAccountCreation.getInitialBalance(), createdPerson);
            return this.accountRepository.save(account);
        }
    }


    public Account depositInAccount(Long accountNumber, DTOAccountDeposit dtoAccountDeposit) throws
            ApiException
    {
        /*
        depositToAccountValidation.setDtoAccountDeposit(dtoAccountDeposit);
        depositToAccountValidation.setAccountNumber(accountNumber);
        String message = depositToAccountValidation.validationEntryData();

        if(!message.isEmpty()){
            List<String> error = List.of(message);

            throw new ApiException (400, error);
        }
         */
        accountValidation.depositAccountValidation(accountNumber, dtoAccountDeposit);

        Account existingAccount = getAccountById(accountNumber);
        existingAccount.setBalance(existingAccount.getBalance().add(dtoAccountDeposit.getAmount()));
        return this.accountRepository.save(existingAccount);
    }


    public DTOAccountTransfer transferToAccount(DTOAccountTransfer dtoAccountTransfer) throws
            ApiException
    {
        /*
        transferAccountValidation.setDtoAccountTransfer(dtoAccountTransfer);
        String message = transferAccountValidation.validationEntryData();

        if(!message.isEmpty()){
            List<String> error = List.of(message);
            throw new ApiException (400, error);
        }
        else{
         */
        accountValidation.transferAccountValidation(dtoAccountTransfer);
        Account existingSourceAccount = getAccountById(dtoAccountTransfer.getSourceAccountNumber());
        Account existingDestinationAccount = getAccountById(dtoAccountTransfer.getDestinationAccountNumber());

        if(existingDestinationAccount.equals(existingSourceAccount)){
            List<String> error = List.of("Las cuentas de origen y destino no pueden ser iguales.");
            throw new ApiException (400, error);
        }

        if(isThereEnoughBalance(existingSourceAccount, dtoAccountTransfer.getAmount())){
            existingSourceAccount.setBalance(existingSourceAccount.getBalance().add(dtoAccountTransfer.getAmount().
                    negate()));
            existingDestinationAccount.setBalance(existingDestinationAccount.getBalance().add(dtoAccountTransfer.
                    getAmount()));
            this.accountRepository.save(existingSourceAccount);
            this.accountRepository.save(existingDestinationAccount);
            return dtoAccountTransfer;
        } else{
            List<String> error = List.of("La cuenta con numero '" + dtoAccountTransfer.getSourceAccountNumber()
                    + "' no tiene suficientes fondos disponibles para realizar la transferencia.");
            throw new ApiException (400, error);
        }

    }

    public List<DTOPocketConsultIn> getPocketsByAccountNumber(Long accountNumber) throws ApiException {
        Account existingAccount = getAccountById(accountNumber);
        DTOPocketConsultOut pockets = pocketService.getPocketsByAccountNumber(existingAccount.getAccountNumber());
        if(pockets.getPockets().isEmpty()){
            List<String> error = List.of("La cuenta con numero '" + accountNumber
                    + "' no tiene bolsillos asociados.");
            throw new ApiException (400, error);
        }
        return pockets.getPockets();
        /*
        String uri = "http://localhost:8080/api/pockets/" + existingAccount.getAccountNumber();
        ResponseEntity<DTOPocketConsultOut> response = new RestTemplate().getForEntity(uri, DTOPocketConsultOut.class);
        if (response.getBody().getPockets().isEmpty()){
            throw new ApiException (404, "La cuenta con numero '" + accountNumber + "' no cuenta con bolsillos.");
        }
        return response.getBody().getPockets();
         */
    }

    public Person getPersonById(String id) throws ApiException {
        try{
            return personService.getPersonById(id);
        } catch(ApiException e){
            return null;
        }

        /*
        String uri = "http://localhost:8080/api/persons/" + id;
        ResponseEntity<Person> response;
        try{
            response = new RestTemplate().getForEntity(uri, Person.class);
        } catch(Exception e){
            return null;
        }
        return response.getBody();
         */
    }

    public Person createPerson(DTOPersonCreate dtoPersonCreate) throws ApiException {
        try{
            return personService.createPerson(dtoPersonCreate);
        } catch(ApiException e){
            return null;
        }
        /*
        String uri = "http://localhost:8080/api/persons";
        return new RestTemplate().postForEntity(uri, person, Person.class);
        */
    }

    private boolean isThereEnoughBalance(Account account, BigDecimal amountToTransfer) {
        return account.getBalance().add(balanceInPocketsOfOneAccount(account.getAccountNumber()).negate())
                .compareTo(amountToTransfer) >= 0;
    }

    public BigDecimal balanceInPocketsOfOneAccount(Long accountNumber){
        BigDecimal sumAmountInPockets = BigDecimal.valueOf(0);
        try{
            DTOPocketConsultOut pocketsInAccount = new DTOPocketConsultOut(getPocketsByAccountNumber(accountNumber));
            if(!pocketsInAccount.getPockets().isEmpty()){
                for (DTOPocketConsultIn pocket: pocketsInAccount.getPockets()){
                    BigDecimal amountInPocket = pocket.getAmount();
                    sumAmountInPockets = sumAmountInPockets.add(amountInPocket);
                }
            }
        } catch (NullPointerException | ApiException e) {
            sumAmountInPockets = BigDecimal.valueOf(0);
        }
        return sumAmountInPockets;
    }

    public void isLoggedInUserTheOwnerOfTheAccount (Long accountNumber,
                                                    String ownerId) throws ApiException {

        List<Account> accounts = accountRepository.findByPersonId(ownerId);
        boolean isTheOwner = false;
        for(Account account: accounts){
            if(accountNumber.equals(account.getAccountNumber())){
                isTheOwner = true;
                break;
            }
        }

        if(!isTheOwner){
            throw new ApiException (403,
                    List.of("El usuario '" + ownerId + "' no cuenta con " +
                            "permisos para acceder a esta cuenta."));
        }
        System.out.println(isTheOwner);
    }
}
